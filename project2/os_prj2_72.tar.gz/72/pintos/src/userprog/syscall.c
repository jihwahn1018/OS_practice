#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "devices/shutdown.h"	/* shutdown_power_off() */
#include "userprog/process.h"	/* process_execute(), process_wait() */
#include "devices/input.h"	/* input_getc() */
#include "threads/vaddr.h"	/* PHYS_BASE */

#include "filesys/filesys.h" //filesys function
#include "filesys/file.h" //file function
#include "filesys/off_t.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);
bool create(const char *file, unsigned initial_size);
bool remove(const char *file);

struct file
{
	struct inode *inode;
	off_t pos;
	bool deny_write;
};

struct lock lock;
void
syscall_init (void) 
{
  lock_init(&lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame *f UNUSED) 
{ 	
  int *esp = f->esp;
  //printf ("system call!\n");
  
  // check for invalid pointers
  if(!is_user_vaddr(f->esp))
      exit(-1);

  /* debug */
  //printf("\nsyscall : %d\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);

  /* system call */
  switch(*(uint32_t*)(f->esp)){

      /* Projects 2 and later  */
      case SYS_HALT:
	  halt();
	  break;
      case SYS_EXIT:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  exit(esp[1]);
	  break;
      case SYS_EXEC:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  f->eax = exec((const char*)esp[1]);
	  break;
      case SYS_WAIT:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  f->eax = wait((pid_t)esp[1]);
	  break;
      case SYS_CREATE:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  if(!is_user_vaddr(f->esp+8)){
		  exit(-1);
	  }
	  f->eax = create((const char*)esp[1], (unsigned)esp[2]); 
	  break;
      case SYS_REMOVE:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  f->eax = remove((const char*)esp[1]);
	  break;
      case SYS_OPEN:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  f->eax = open((const char*)esp[1]);
	  break;
      case SYS_FILESIZE:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  f->eax = filesize(esp[1]);
	  break;
      case SYS_READ:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  if(!is_user_vaddr(f->esp+8)){
		  exit(-1);
	  }
	  if(!is_user_vaddr(f->esp+12)){
		  exit(-1);
	  }
	  f->eax = read(esp[1], (void*)esp[2], (unsigned)esp[3]);
	  break;
      case SYS_WRITE:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  if(!is_user_vaddr(f->esp+8)){
		  exit(-1);
	  }
	  if(!is_user_vaddr(f->esp+12)){
		  exit(-1);
	  }
	  f->eax = write(esp[1], (void*)esp[2], (unsigned)esp[3]);
	  break;
      case SYS_SEEK:
	  if(!is_user_vaddr(f->esp+4)){
		  exit(-1);
	  }
	  if(!is_user_vaddr(f->esp+8)){
		  exit(-1);
	  }
	  seek(esp[1], (unsigned)esp[2]);
	  break;
      case SYS_TELL:
	  if(!is_user_vaddr(f->esp)){
		  exit(-1);
	  }
	  f->eax = tell(esp[1]);
	  break;
      case SYS_CLOSE:
	  if(!is_user_vaddr(f->esp)){
		  exit(-1);
	  }
	  close(esp[1]);
	  break;
    
      /* Project 3 and optionally Project 4 */
      case SYS_MMAP:
	  break;
      case SYS_MUNMAP:
	  break;

      /* Project 4 only. */
      case SYS_CHDIR:
	  break;
      case SYS_MKDIR:
	  break;

      /* Additional system calls */
      case SYS_FIBO:
	  f->eax = fibonacci(esp[1]);
	  break;
      case SYS_FOURSUM:
	  f->eax = sum_of_four_int(esp[1], esp[2], esp[3], esp[4]);
	  break;
  }
}

void halt(){
    shutdown_power_off();
}

void exit(int status){
    char *name, *tok;
	int i=3;
    name = strtok_r((char *)thread_name(), " ", &tok);
   
    if(status < 0)
	status = -1;

    thread_current()->exit_status = status;    

	while(thread_current()->fd[i] != NULL && i < 128){
		close(i);
		i++;
	}
	
	printf("%s: exit(%d)\n", name, status);
    thread_exit();
}

pid_t exec(const char *cmd){
    return process_execute(cmd);
}

int wait(pid_t pid){
    return process_wait((tid_t)pid);
}

int read(int fd, void *buf, unsigned size){
    unsigned i;
	
    if(buf>=PHYS_BASE)
	exit(-1);
    if(fd == 0){
		lock_acquire(&lock);
		for(i=0; i<size; i++){
		    *(uint8_t *)(buf+i) = input_getc();
			if(*(uint8_t *)(buf+i) == '\0'){
				lock_release(&lock);
				return i;
			}
		}
		if(i == size){
			lock_release(&lock);
		    return size;
		}
    }
    else if(fd > 2 && fd < 128){
		struct file *file = thread_current()->fd[fd];
		if(file == NULL)
			exit(-1);
	//	if(!is_user_vaddr(file)){
	//		exit(-1);
	//	}
	//	printf("read deny %s \n\n\n\n",thread_current()->name);
		lock_acquire(&lock);
		int num = file_read(file, buf, size);
		lock_release(&lock);
	//	printf("read allow %s \n\n\n\n", thread_current()->name);
		return num;
	}
	return -1;
}

int write(int fd, const void *buf, unsigned size){

    if(buf>=PHYS_BASE)
		exit(-1);

    if(fd == 1){
		lock_acquire(&lock);
		putbuf(buf, size);
		lock_release(&lock);
		return size;
    }
    else if(fd > 2 && fd < 128){
		struct file *file = thread_current()->fd[fd];
		if(file == NULL)
			exit(-1);
	//	if(!is_user_vaddr(file)){
	//		exit(-1);
	//	}
	//	if(file->deny_write){
	//		exit(-1);
	//	}
	//	printf("write %s \n\n\n\n",thread_current()->name);
		lock_acquire(&lock);
		int num = file_write(thread_current()->fd[fd], buf, size);
		lock_release(&lock);
		return num;
	}
	return -1;
}

int fibonacci (int n){
  int i;
  int f0 = 0, f1 = 1, f2 = 1;
  if(n == 0)
     return f0;
  else if(n == 1)
     return f1;
  else{
    for(i=0;i<n-1;i++){
	f2 = f0+f1;
	f0=f1;
	f1=f2;
    }
    return f2;
  }
}

int sum_of_four_int(int a, int b, int c, int d){
  return a+b+c+d;
}
bool create(const char *file, unsigned initial_size){
 	if(!is_user_vaddr((void*)file)){
		exit(-1);
	}
	if(file == NULL)
		exit(-1);
	
	//printf("create %s\n\n\n\n",file);

	if(filesys_create(file, initial_size)){
		return true;
	}
	else
		return false;
}
bool remove(const char *file){
	if(!is_user_vaddr((void*)file)){
		exit(-1);
	}
	if(file == NULL)
		exit(-1);

	/*int j=0;
	char cmd_name[256];
	while(file[i] != '\0' && file[i] != ' '){
		 cmd_name[i] = file[i];
		  j++
	}
	cmd_name[i]='\0';
	*/
	if( filesys_remove(file))
		return true;
	else
		return false;
}
int open(const char *file){
	int i;
	if(file ==NULL)
		return -1;
	lock_acquire(&lock);
	int j=0;
	char cmd_name[256];
	while(thread_current()->name[j] != '\0' && thread_current()->name[j] != ' '){
		 cmd_name[j] = thread_current()->name[j];
		  j++;
	}
	cmd_name[j]='\0';
	
	//printf("open %s\n\n\n\n\n",file);
	struct file *o_file = filesys_open(file);
	if(o_file == NULL){
		lock_release(&lock);
		return -1;
	}
	for(i=3 ; i< 128 ; i++){
		if(thread_current()->fd[i]==NULL){
			if(strcmp(cmd_name, file) == 0)
				file_deny_write(o_file);
			thread_current()->fd[i] = o_file;
			lock_release(&lock);
			return i;
		}
	}
	lock_release(&lock);
	return -1;
}
int filesize(int fd){
	if(thread_current()->fd[fd] != NULL){
		struct file *file = thread_current()->fd[fd];
		return file_length(file);
	}
	else
		exit(-1);
}
void seek(int fd, unsigned position){
	if(thread_current()->fd[fd] != NULL)
		file_seek(thread_current()->fd[fd], position);
	else
		exit(-1);
}
unsigned tell(int fd){
	if(thread_current()->fd[fd] != NULL){
		unsigned position = file_tell(thread_current()->fd[fd]);
		return position;
	}
	else
		exit(-1);
}
void close(int fd){
	if(thread_current()->fd[fd] != NULL){
		file_close(thread_current()->fd[fd]);
		thread_current()->fd[fd] = NULL;
	}
	else
		exit(-1);
}
