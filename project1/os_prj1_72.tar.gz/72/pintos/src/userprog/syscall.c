#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "devices/shutdown.h"	/* shutdown_power_off() */
#include "userprog/process.h"	/* process_execute(), process_wait() */
#include "devices/input.h"	/* input_getc() */
#include "threads/vaddr.h"	/* PHYS_BASE */

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame *f UNUSED) 
{
  int *esp = f->esp;
  //printf ("system call!\n");
  
  // check for invalid pointers
  if(!is_user_vaddr(f->esp))
      exit(-1);

  /* debug */
  //printf("\nsyscall : %d\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);

  /* system call */
  switch(*(uint32_t*)(f->esp)){

      /* Projects 2 and later  */
      case SYS_HALT:
	  halt();
	  break;
      case SYS_EXIT:
	  exit(esp[1]);
	  break;
      case SYS_EXEC:
	  f->eax = exec((const char*)esp[1]);
	  break;
      case SYS_WAIT:
	  f->eax = wait((pid_t)esp[1]);
	  break;
      case SYS_CREATE:
	  break;
      case SYS_REMOVE:
	  break;
      case SYS_OPEN:
	  break;
      case SYS_FILESIZE:
	  break;
      case SYS_READ:
	  f->eax = read(esp[1], (void*)esp[2], (unsigned)esp[3]);
	  break;
      case SYS_WRITE:
	  f->eax = write(esp[1], (void*)esp[2], (unsigned)esp[3]);
	  break;
      case SYS_SEEK:
	  break;
      case SYS_TELL:
	  break;
      case SYS_CLOSE:
	  break;
    
      /* Project 3 and optionally Project 4 */
      case SYS_MMAP:
	  break;
      case SYS_MUNMAP:
	  break;

      /* Project 4 only. */
      case SYS_CHDIR:
	  break;
      case SYS_MKDIR:
	  break;

      /* Additional system calls */
      case SYS_FIBO:
	  f->eax = fibonacci(esp[1]);
	  break;
      case SYS_FOURSUM:
	  f->eax = sum_of_four_int(esp[1], esp[2], esp[3], esp[4]);
	  break;
  }
}

void halt(){
    shutdown_power_off();
}

void exit(int status){
    char *name, *tok;
    name = strtok_r((char *)thread_name(), " ", &tok);
   
    if(status < 0)
	status = -1;

    thread_current()->exit_status = status;    
    printf("%s: exit(%d)\n", name, status);
    thread_exit();
}

pid_t exec(const char *cmd){
    return process_execute(cmd);
}

int wait(pid_t pid){
    return process_wait((tid_t)pid);
}

int read(int fd, void *buf, unsigned size){
    unsigned i;
    
    if(buf>=PHYS_BASE)
	exit(-1);

    if(fd == 0){
	for(i=0; i<size; i++)
	    *(uint8_t*)(buf+i) = input_getc();
	if(i == size)
	    return size;
	else
	    return -1;
    }
    else
	return -1;
}

int write(int fd, const void *buf, unsigned size){
    
    if(buf>=PHYS_BASE)
	exit(-1);
    
    if(fd == 1){
	putbuf(buf, size);
	return size;
    }
    else
	return -1;
}

int fibonacci (int n){
  int i;
  int f0 = 0, f1 = 1, f2 = 1;
  if(n == 0)
     return f0;
  else if(n == 1)
     return f1;
  else{
    for(i=0;i<n-1;i++){
	f2 = f0+f1;
	f0=f1;
	f1=f2;
    }
    return f2;
  }
}

int sum_of_four_int(int a, int b, int c, int d){
  return a+b+c+d;
}
